#DO NOT MODIFY THE CODE IN THIS FILE
#File: Proj06.py
#Rev 12/04/22
'''
Among other things, this assignment requires you to write a program 
that demonstrates your knowledge of the following topics:
Creating a figure with multiple subplots on a grid.
Flattening the axes on a figure for convenient access (optional)
Setting labels on the horizontal and vertical axes for each subplot
Setting a title on each subplot
Setting a display limit on the horizontal axis of a subplot
Plotting multiple curves on the same subplot
Setting grids on subplots
Setting a title on the figure
Showing the figure
'''

from Proj06Runner import Runner
#Call the function named run in the class named Runner in the
#student's file named Proj06Runner.py
Runner.run()




