#DO NOT MODIFY THE CODE IN THIS FILE
#File: Proj09.py
#Rev 12/05/22
'''
This assignment requires you to write a program 
demonstrating your knowledge of visualization major 
and minor grid lines as well as material leading 
up to that topic.
'''

from Proj09Runner import Runner
#Call student's run method
Runner.run()




